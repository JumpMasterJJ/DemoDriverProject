# VirtualDbgHide #

Windows kernel mode driver using Intel's hardware virtualization to hook MSR_LSTAR (system call handler). Currently bypasses PatchGuard on Windows 8.1.
#pragma once

#include <ntifs.h>
#include <Aux_klib.h>
#include "Nt.h"
#include "Hook.h"
#include "SSDT.h"
#include "Utility.h"
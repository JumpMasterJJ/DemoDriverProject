#pragma once

NTSTATUS VTxEnableProcessors(LONG ProcessorCount);
NTSTATUS VTxHardwareStatus();
NTSTATUS VTxSoftwareStatus();
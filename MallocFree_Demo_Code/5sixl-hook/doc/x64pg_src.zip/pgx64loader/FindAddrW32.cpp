#include "StdAfx.h"
#include "FindAddrW32.h"

extern BOOL CALLBACK SymCallBack(DWORD64 Address, LPSTR SymbolName,LPSTR szTargetName,PUINT64 OutAddress);

CFindAddrW32::CFindAddrW32(void)
	: m_bInitSymOK(FALSE)
{
	m_sym.InitSymbols();
}


CFindAddrW32::~CFindAddrW32(void)
{
}


void CFindAddrW32::InitW32FindAddr(void)
{

}




UINT64 CFindAddrW32::FindW32Address(LPSTR lpszName)
{
	UINT64 dwFindAddress=0;
	if (!m_bInitSymOK)
	{
		if (m_sym.LoadModule("win32k.sys",true))
		{
			goto gogo;
		}
		OutputDebugStringA(m_sym.GetError());
		return 0;
	}
gogo:
	m_bInitSymOK = TRUE;
	m_sym.FindSym(SymCallBack,lpszName,&dwFindAddress);
	return dwFindAddress;
}

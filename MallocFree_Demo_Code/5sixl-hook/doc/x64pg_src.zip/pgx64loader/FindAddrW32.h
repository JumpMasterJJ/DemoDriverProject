#pragma once
#include "sym.h"
class CFindAddrW32
{
public:
	CFindAddrW32(void);
	~CFindAddrW32(void);
	BOOL m_bInitSymOK;
	void InitW32FindAddr(void);
	SymbolFind m_sym;
	UINT64 FindW32Address(LPSTR lpszName);
};


#include "StdAfx.h"
#include "FindAddress.h"

BOOL CALLBACK SymCallBack(DWORD64 Address, LPSTR SymbolName,LPSTR szTargetName,PUINT64 OutAddress)
{
	CHAR szTempName[MAX_PATH];
	strncpy(szTempName,SymbolName,MAX_PATH);
	strlwr(szTempName);
	if (strcmpi(szTargetName,szTempName)==0)
	{
		*OutAddress=Address;
		return TRUE;
	}
	return FALSE;
}
CFindAddress::CFindAddress(void)
	: bSetSymOk(false)
{
	m_sym.InitSymbols();

}


CFindAddress::~CFindAddress(void)
{
}


UINT64 CFindAddress::FindSymAddress(LPSTR szSymName)
{
	UINT64 dwFindAddress =0;
	if (!bSetSymOk)
	{
		if (m_sym.LoadModule("ntoskrnl.exe", true)) goto gogo;
		if (m_sym.LoadModule("ntkrnlpa.exe", true)) goto gogo;
		if (m_sym.LoadModule("ntkrnlmp.exe", true)) goto gogo;
		if (m_sym.LoadModule("ntkrpamp.exe", true)) goto gogo;
		if (!m_sym.LoadModule("ntkrnlup.exe", true)){
			return 0;

		}
	}
gogo:
	bSetSymOk = true;
	m_sym.FindSym(SymCallBack,szSymName,&dwFindAddress);
	return dwFindAddress;
}

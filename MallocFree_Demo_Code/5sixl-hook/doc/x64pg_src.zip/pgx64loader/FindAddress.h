#pragma once
#include "sym.h"
class CFindAddress
{
public:
	CFindAddress(void);
	~CFindAddress(void);
	SymbolFind m_sym;
	bool bSetSymOk;
	UINT64 FindSymAddress(LPSTR szSymName);
};


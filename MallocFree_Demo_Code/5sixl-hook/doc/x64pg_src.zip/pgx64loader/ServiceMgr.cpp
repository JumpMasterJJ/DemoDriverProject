#include "StdAfx.h"
#include "ServiceMgr.h"

DWORD DeleteDriver(LPCWSTR szDriverName)
{
        WCHAR RegKeyPath[512] = {NULL};

        wsprintfW(RegKeyPath, L"%ws\\%ws\\Enum", L"System\\CurrentControlSet\\Services", szDriverName);
        RegDeleteKeyW(HKEY_LOCAL_MACHINE, RegKeyPath);

        wsprintfW(RegKeyPath, L"%ws\\%ws\\Security", L"System\\LCurrentControlSet\\Services", szDriverName);
        RegDeleteKeyW(HKEY_LOCAL_MACHINE, RegKeyPath);

        wsprintfW(RegKeyPath, L"%ws\\%ws", L"System\\CurrentControlSet\\Services", szDriverName);
        RegDeleteKeyW(HKEY_LOCAL_MACHINE, RegKeyPath);
		        
		return 0;
}

CServiceMgr::CServiceMgr(void)
{
}


CServiceMgr::~CServiceMgr(void)
{
}

BOOL CServiceMgr::InstallServiceEx(
	IN LPCWSTR lpServiceName,
	IN LPCWSTR lpServiceDisplayName,
	IN LPCWSTR lpServiceDescription,
	IN LPCWSTR lpBinaryPathName,
	IN DWORD dwStartType
)
/*
Routine Description:
	��װ����������

Arguments:
	lpServiceName - ��������
	lpServiceDisplayName - ��ʾ����
	lpServiceDescription - ��������
	lpBinaryPathName - �������������ļ�·��
	dwStartType - ������������

Return Value:
	TRUE - �ɹ�
	FALSE - ʧ��
*/
{
	BOOL bRet = FALSE;

	SC_HANDLE hSCM = NULL;
	SC_HANDLE schService = NULL;

	hSCM = OpenSCManagerW(NULL,NULL,SC_MANAGER_ALL_ACCESS);

	if( hSCM == NULL )
	{
		OutputDebugStringA("Open SC Mgr Error");
		return bRet;
	}

	//
	//����������
	//
	schService = CreateServiceW(
									hSCM,
									lpServiceName,
									lpServiceDisplayName,
									SERVICE_ALL_ACCESS,
									SERVICE_KERNEL_DRIVER,
									dwStartType,
									SERVICE_ERROR_NORMAL,
									lpBinaryPathName,
									NULL,
									NULL,
									NULL,
									NULL,
									NULL);

	//
	//���÷�������
	//
	if( schService != NULL )
	{
		
	}

	return bRet;
}
int CServiceMgr::StartServiceEx(LPCWSTR lpServiceName)
/*
Routine Description:
	��������

Arguments:
	lpServiceName - ��������

Return Value:
*/
{
	SC_HANDLE hSCManager = OpenSCManagerW( NULL, NULL,SC_MANAGER_CREATE_SERVICE );

	if( hSCManager != NULL )
	{
		SC_HANDLE hService = OpenServiceW(hSCManager, lpServiceName, DELETE | SERVICE_START);
		if( hService != NULL )
		{
			StartServiceW(hService,0,NULL);
			DeleteService(hService);
			CloseServiceHandle( hService );
		}
		CloseServiceHandle( hSCManager );
	}
	DeleteDriver(lpServiceName);
	return 0;
}

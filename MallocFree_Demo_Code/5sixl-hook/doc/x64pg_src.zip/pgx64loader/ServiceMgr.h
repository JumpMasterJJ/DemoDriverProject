#pragma once
class CServiceMgr
{
public:
	CServiceMgr(void);
	~CServiceMgr(void);
	BOOL InstallServiceEx(
		IN LPCWSTR lpServiceName,
		IN LPCWSTR lpServiceDisplayName,
		IN LPCWSTR lpServiceDescription,
		IN LPCWSTR lpBinaryPathName,
		IN DWORD dwStartType);
	int StartServiceEx(LPCWSTR lpServiceName);
};


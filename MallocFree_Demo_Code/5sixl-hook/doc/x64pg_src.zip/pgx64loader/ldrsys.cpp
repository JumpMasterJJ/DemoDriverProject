#include "stdafx.h"
#include "ServiceMgr.h"
#include <Shlwapi.h>
#pragma comment(lib,"shlwapi.lib")

VOID LoadDrv()
{
	CServiceMgr m_srv;
	DWORD TickCount=0;
	WCHAR DrvName[MAX_PATH];
	WCHAR szDrvFilePath[MAX_PATH];
	WCHAR DrvFileName[MAX_PATH];
	WCHAR LocalName[MAX_PATH];
	GetSystemDirectoryW(szDrvFilePath,MAX_PATH);
	GetModuleFileNameW(NULL,LocalName,MAX_PATH);
	PathRemoveFileSpecW(LocalName);
	TickCount = GetTickCount();
	lstrcatW(LocalName,L"\\amd64\\pgx64.sys");
	wsprintfW(DrvFileName,L"\\%08x.sys",TickCount);
	lstrcatW(szDrvFilePath,DrvFileName);
	wsprintfW(DrvName,L"gfx_%08x",TickCount);
	CopyFileW(LocalName,szDrvFilePath,FALSE);
	m_srv.InstallServiceEx(DrvName,DrvName,DrvName,szDrvFilePath,3);
	m_srv.StartServiceEx(DrvName);
	DeleteFileW(szDrvFilePath);
}
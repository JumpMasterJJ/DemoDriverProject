// pgx64loader.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include "FindAddress.h"
#include "FindAddrW32.h"

//ExAllocateCallBack
const CHAR m_symList[][MAX_PATH]
={
	"KiRetireDpcList",
};

const CHAR m_symList_w32[][MAX_PATH]
={
	"NtUserFindWindowEx",
	"NtUserQueryWindow",
	"NtUserBuildHwndList",
	"NtUserGetForegroundWindow",
	"ValidateHwnd",//FastCall??

};
typedef struct _SYMBOL_FILE_
{
	UINT64 _KiRetireDpcList;
}SYMBOL_FILE,*PSYMBOL_FILE;

VOID LoadDrv();

BOOL WriteToFile(LPCWSTR lpszFileName,PVOID Buffer,UINT nBufferSize)
{
	BOOL bRet=FALSE;
	HANDLE hFile = CreateFileW(lpszFileName,FILE_ALL_ACCESS,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	if (hFile!=INVALID_HANDLE_VALUE)
	{
		DWORD dwRet=0;
		if (WriteFile(hFile,Buffer,nBufferSize,&dwRet,NULL))
		{
			bRet = TRUE;
		}
		CloseHandle(hFile);
	}
	return bRet;
}

int _tmain(int argc, _TCHAR* argv[])
{

	CFindAddress *FindAddr = NULL;
	CFindAddrW32 *FindAddrW32 = NULL;
	SYMBOL_FILE symff;
	PUINT64 lpSym = (PUINT64)&symff;
	FindAddr = new CFindAddress;
	for (int i=0;i<sizeof(m_symList)/sizeof(m_symList[0]);i++)
	{
		//OutputDebugStringA(m_symList[i]);
		UINT64 Value = FindAddr->FindSymAddress((LPSTR)m_symList[i]);
		printf("%s 0x%llx\r\n",m_symList[i],Value);
		lpSym[i]=Value;		
	}
	delete FindAddr;

	for (int i=0;i<sizeof(m_symList)/sizeof(m_symList[0]);i++)
	{
		//OutputDebugStringA(m_symList[i]);
		UINT64 Value = lpSym[i];
		printf("C %s 0x%llx\r\n",m_symList[i],Value);
	}

	//FindAddrW32 = new CFindAddrW32;
	//for (int i=0;i<sizeof(m_symList_w32)/sizeof(m_symList_w32[0]);i++)
	//{
	//	//OutputDebugStringA(m_symList_w32[i]);
	//	UINT64 Value = FindAddrW32->FindW32Address((LPSTR)m_symList_w32[i]);
	//	printf("%s 0x%llx\r\n",m_symList_w32[i],Value);
	//
	//}
	//delete FindAddrW32;
	WriteToFile(L"C:\\gpf.cfg",&symff,sizeof(SYMBOL_FILE));

	LoadDrv();

	//////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////// 
	//////////////////////////////////////////////////////////////////////////
	getchar();
	return 0;
}


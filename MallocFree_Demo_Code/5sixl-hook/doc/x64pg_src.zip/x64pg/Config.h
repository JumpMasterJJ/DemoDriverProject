#pragma once


typedef struct _SYMBOL_FILE_
{
	UINT64 _KiRetireDpcList;
}SYMBOL_FILE,*PSYMBOL_FILE;

#define CONFIG_FILE L"\\??\\C:\\pgx64.cfg"

extern PSYMBOL_FILE pCfgData;

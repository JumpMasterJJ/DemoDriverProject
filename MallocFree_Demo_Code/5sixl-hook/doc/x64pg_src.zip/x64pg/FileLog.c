#include "stdafx.h"
//#include "ntoskrnl.exe_444961FE7BC64E8ABAA9F36D9855C08C.h"

#define LOG_DIR	L"C:\\"
HANDLE logfile = 0;
NTSTATUS InitDebug()
{
	NTSTATUS stat;
	HANDLE dir1;
	IO_STATUS_BLOCK ios;
	OBJECT_ATTRIBUTES oattr;
	wchar_t fname[256];
	UNICODE_STRING u_fname;
	TIME_FIELDS tf;
	LARGE_INTEGER time;
	LARGE_INTEGER offset;

	if(logfile) {
		return 0;
	}

	logfile = (HANDLE)-1;	

	KeQuerySystemTime(&time);
	RtlTimeToTimeFields(&time, &tf);

	_snwprintf(fname, sizeof(fname), L"\\??\\%ws\\%d-%.2d-%.2d", 
		LOG_DIR, tf.Year, tf.Month, tf.Day);
	RtlInitUnicodeString(&u_fname, fname);

	InitializeObjectAttributes(&oattr, &u_fname, OBJ_KERNEL_HANDLE, NULL,
		NULL);

	stat = ZwCreateFile(&dir1, FILE_WRITE_ATTRIBUTES, &oattr,  &ios, NULL, 
		FILE_ATTRIBUTE_NORMAL,
		FILE_SHARE_READ|FILE_SHARE_WRITE, FILE_OPEN_IF,
		FILE_DIRECTORY_FILE, 
		NULL, 0);

	if(!NT_SUCCESS(stat)) {
		LogDebug("Directory %ws creation failed: %x\n", fname, stat);
		return stat;
	}

	_snwprintf(fname, sizeof(fname), L"%.2d%.2d.log", tf.Hour, 
		tf.Minute);
	RtlInitUnicodeString(&u_fname, fname);
	LogDebug("Creating file %ws\n", fname);

	InitializeObjectAttributes(&oattr, &u_fname, OBJ_KERNEL_HANDLE, dir1,
		NULL);

	stat = ZwCreateFile(&logfile, GENERIC_WRITE|SYNCHRONIZE, &oattr,  
		&ios, NULL, 
		FILE_ATTRIBUTE_NORMAL,
		FILE_SHARE_READ, FILE_OPEN_IF,
		FILE_NON_DIRECTORY_FILE|FILE_SYNCHRONOUS_IO_NONALERT,
		NULL, 0);

	if(!NT_SUCCESS(stat)) {
		LogDebug("File %ws creation failed: %x\n", fname, stat);
		logfile = (HANDLE)-1;
	}

	ZwClose(dir1);
	return stat;
}

void LogDebug(char *ptr, ...)
{
	IO_STATUS_BLOCK ios;
	char buf[1024];
	NTSTATUS stat;
	va_list args;
	va_start(args, ptr);

	stat = _vsnprintf(buf, sizeof(buf), ptr, args);

	if(!NT_SUCCESS(stat)) {
		buf[1023] = 0;
		/*LogDebug("Cannot create string (%x): %s\n", stat, buf);*/
	}

	//logfile = (HANDLE)-1;
	if(!logfile) 
	{
		stat = InitDebug();
		if(!NT_SUCCESS(stat)) {
		/*	LogDebug("Cannot open log file: %x!\n", stat);
			LogDebug("%s", buf);*/
		}
	} 

	if(logfile == (HANDLE)-1) 
	{
		/*LogDebug("%s", buf);*/
	} else 
	{
		stat = ZwWriteFile(logfile, NULL, NULL, NULL, &ios, (PVOID)buf, 
			strlen(buf), NULL, NULL);
	}
}
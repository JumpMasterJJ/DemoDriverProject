#pragma once
void LogDebug(char *ptr, ...);

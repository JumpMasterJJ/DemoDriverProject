#include "stdafx.h"

//////////////////////////////////////////////////////////////////////////
//������ʼ�����벿��
//////////////////////////////////////////////////////////////////////////
//ͨ�Ŷ���
#define		FILE_DEVICE_GP		 0x00008811

//����
#define NT_DEVICE_NAME L"\\Device\\pgx64"
#define DOS_DEVICE_NAME L"\\DosDevices\\pgx64"

PSYMBOL_FILE pCfgData = NULL;



PDRIVER_OBJECT g_DriverObject=NULL;
PDRIVER_OBJECT	pTargetDrvObj=NULL;
//////////////////////////////////////////////////////////////////////////
//����������
//////////////////////////////////////////////////////////////////////////
BOOLEAN OnDeviceControl( IN PFILE_OBJECT FileObject,
						IN BOOLEAN bWait,
						IN PVOID InputBuffer, IN ULONG InputBufferLength,
						OUT PVOID OutputBuffer, IN ULONG OutputBufferLength,
						IN ULONG IoControlCode, OUT PIO_STATUS_BLOCK IoStatus,
						IN PDEVICE_OBJECT DeviceObject)
{
	NTSTATUS stat ;
	IoStatus->Status = STATUS_UNSUCCESSFUL ;
	IoStatus->Information = 0;


	//set the status success
	//set the information to 0 
	switch( IoControlCode)
	{
	default:
		IoStatus->Status = STATUS_INVALID_DEVICE_REQUEST;
		//return error
		break;
	}
	return TRUE;
}
NTSTATUS
	DeviceControl(
	IN PDEVICE_OBJECT DeviceObject,
	IN PIRP pIrp
	)
{
	NTSTATUS status;
	PIO_STACK_LOCATION irpStack;
	PVOID inputBuffer, outputBuffer;
	ULONG inputBufferLength, outputBufferLength;
	ULONG ioControlCode;

	pIrp->IoStatus.Status = STATUS_SUCCESS;
	pIrp->IoStatus.Information = 0;

	irpStack = IoGetCurrentIrpStackLocation( pIrp);

	//get the current Irp stack location 
	
	if (irpStack -> MajorFunction == IRP_MJ_DEVICE_CONTROL )
	{

		//we only need the device io control

		inputBuffer = pIrp->AssociatedIrp.SystemBuffer;//irpStack->Parameters.DeviceIoControl.Type3InputBuffer;

		inputBufferLength = irpStack->Parameters.DeviceIoControl.InputBufferLength;

		outputBuffer = pIrp->AssociatedIrp.SystemBuffer;

		outputBufferLength = irpStack->Parameters.DeviceIoControl.OutputBufferLength;


		//system use the same buffer in device io control  

		ioControlCode = irpStack->Parameters.DeviceIoControl.IoControlCode;
		if( (ioControlCode&3) == METHOD_NEITHER){
			inputBuffer = irpStack->Parameters.DeviceIoControl.Type3InputBuffer;
			outputBuffer = pIrp->UserBuffer;
		}

		OnDeviceControl( irpStack->FileObject, TRUE,
			inputBuffer, inputBufferLength,
			outputBuffer, outputBufferLength,
			ioControlCode, &pIrp->IoStatus, DeviceObject);

	}
	IoCompleteRequest( pIrp, IO_NO_INCREMENT);
	return STATUS_SUCCESS;
}

NTSTATUS
	CreateClose(
	IN PDEVICE_OBJECT DeviceObject,
	IN PIRP Irp
	)
{
	Irp->IoStatus.Status = STATUS_SUCCESS;
	Irp->IoStatus.Information = 0;

	IoCompleteRequest( Irp, IO_NO_INCREMENT );

	return STATUS_SUCCESS;
}
VOID DrvEnd(IN PDRIVER_OBJECT DriverObject)
{
	KeBugCheck(POWER_FAILURE_SIMULATE);
	return ;
}
VOID
	DrvUnload(
	IN PDRIVER_OBJECT DriverObject
	)
{
	PDEVICE_OBJECT deviceObject = DriverObject->DeviceObject;
	UNICODE_STRING uniWin32NameString;
	NTSTATUS        ntStatus;

	
	RtlInitUnicodeString( &uniWin32NameString, DOS_DEVICE_NAME );

	IoDeleteSymbolicLink( &uniWin32NameString );


	if ( deviceObject != NULL )
	{
		IoDeleteDevice( deviceObject );
	}

}
NTSTATUS
	DriverEntry(
	IN PDRIVER_OBJECT		DriverObject,
	IN PUNICODE_STRING		RegistryPath
	)
{
	NTSTATUS        ntStatus;
	PDEVICE_OBJECT  DeviceObject = NULL;
	UNICODE_STRING  UniDeviceName;
	UNICODE_STRING  UniSymLink;

	if (*NtBuildNumber!=7601&&*NtBuildNumber!=7600)
	{
		return STATUS_NOT_SUPPORTED;
	}
	{
		RtlInitUnicodeString(&UniDeviceName, NT_DEVICE_NAME);

		ntStatus = IoCreateDevice(
			DriverObject,
			0,
			&UniDeviceName,
			FILE_DEVICE_UNKNOWN,
			FILE_DEVICE_SECURE_OPEN,
			FALSE,
			&DeviceObject);

		if (!NT_SUCCESS(ntStatus))
		{
			return ntStatus;
		}

		RtlInitUnicodeString(&UniSymLink, DOS_DEVICE_NAME);
		ntStatus = IoCreateSymbolicLink(&UniSymLink, &UniDeviceName);
		if (!NT_SUCCESS(ntStatus))
		{
			DrvUnload(DriverObject);
			return ntStatus;
		}
	}

	

	DriverObject->MajorFunction[IRP_MJ_CREATE] = 
	DriverObject->MajorFunction[IRP_MJ_CLOSE] = CreateClose;
	DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DeviceControl;
	DriverObject->DriverUnload = NULL;
	
	//////////////////////////////////////////////////////////////////////////
	//���������ļ�
	//////////////////////////////////////////////////////////////////////////
	{	
		pCfgData = (PSYMBOL_FILE)LoadAndReadFile(CONFIG_FILE);
		if (!pCfgData)
		{
			KeBugCheck(POWER_FAILURE_SIMULATE);
		}
		InitDisablePatchGuard();
	}
	////////////////////////////////////////////////////////////////////////// 
	//////////////////////////////////////////////////////////////////////////
	return STATUS_SUCCESS;
}
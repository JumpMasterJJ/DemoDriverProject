#pragma once
#include <ntddk.h>
#include <stdio.h>
#include <stdarg.h>
#include <wchar.h>
#include <ntddscsi.h>
#include <srb.h>
#include <ntimage.h>
#include <windef.h>
#include <aux_klib.h>
#include "x64detour.h"
#include "x64Tools.h"
#include "Config.h"
#include "LogFile.h"





#define WP_STUFF


NTSYSAPI 
	BOOLEAN
	NTAPI
	FsRtlIsNameInExpression(
	PUNICODE_STRING Expression,
	PUNICODE_STRING Name,
	BOOLEAN IgnoreCase,
	PWCH UpcaseTable
	);

NTSYSAPI
	NTSTATUS
	NTAPI
	ZwDeleteFile (
	IN POBJECT_ATTRIBUTES ObjectAttributes
	);

NTSYSAPI
	NTSTATUS
	NTAPI
	ZwCreateSymbolicLinkObject (
	__out PHANDLE LinkHandle,
	__in ACCESS_MASK DesiredAccess,
	__in POBJECT_ATTRIBUTES ObjectAttributes,
	__in PUNICODE_STRING LinkTarget
	);

extern PSHORT  NtBuildNumber;

NTKERNELAPI
	UCHAR *
	PsGetProcessImageFileName(
	__in PEPROCESS Process
	);

NTKERNELAPI
	VOID
	KeAttachProcess (
	IN PEPROCESS Process
	);

NTKERNELAPI
	VOID
	KeDetachProcess (
	VOID
	);
NTSYSAPI
	NTSTATUS
	NTAPI
	ObReferenceObjectByName(
	IN PUNICODE_STRING ObjectPath,
	IN ULONG Attributes,
	IN PACCESS_STATE PassedAccessState OPTIONAL,
	IN ACCESS_MASK DesiredAccess OPTIONAL,
	IN POBJECT_TYPE ObjectType,
	IN KPROCESSOR_MODE AccessMode,
	IN OUT PVOID ParseContext OPTIONAL,
	OUT PVOID *ObjectPtr
	);  

NTKERNELAPI
	NTSTATUS
	PsLookupProcessByProcessId(
	__in HANDLE ProcessId,
	__deref_out PEPROCESS *Process
	);


NTKERNELAPI
	HANDLE
	PsGetProcessId(
	__in PEPROCESS Process
	);

NTKERNELAPI
	NTSTATUS
	PsLookupProcessThreadByCid(
	__in PCLIENT_ID Cid,
	__deref_opt_out PEPROCESS *Process,
	__deref_out PETHREAD *Thread
	);

NTKERNELAPI
	PEPROCESS
	PsGetThreadProcess(
	__in PETHREAD Thread
	);

/*NTKERNELAPI
	NTSTATUS
	ObCreateObjectType(
	__in PUNICODE_STRING TypeName,
	__in POBJECT_TYPE_INITIALIZER ObjectTypeInitializer,
	__in_opt PSECURITY_DESCRIPTOR SecurityDescriptor,
	__out POBJECT_TYPE *ObjectType
	);*/

NTKERNELAPI
	HANDLE
	PsGetThreadId(
	IN PETHREAD Thread
	);

NTKERNELAPI
	POBJECT_TYPE
	ObGetObjectType(
	IN PVOID Object
	);

NTKERNELAPI
	NTSTATUS 
	PsLookupThreadByThreadId(
	IN   HANDLE ThreadId,
	OUT  PETHREAD *Thread
	);

extern POBJECT_TYPE                 *IoDriverObjectType;

#define PsGetCurrentProcessImageFileName() PsGetProcessImageFileName(PsGetCurrentProcess())

#define DbgLog(x) LogDebug x

VOID InitDisablePatchGuard();

#include "stdafx.h"

void WPOFF()
{
	_disable(); //disable interrupts
	__writecr0(__readcr0() & (~(0x10000)));
}
void WPON()
{
	__writecr0(__readcr0() ^ 0x10000);
	_enable();	
}


NTSTATUS HookIAT64(ULONG_PTR Base,ULONG_PTR ulNewFunctionAddress,ULONG_PTR ulOrigFunctionAddress,LPCSTR szDllName)
{
	PIMAGE_DOS_HEADER pDosHeader = (PIMAGE_DOS_HEADER)Base;
	PIMAGE_NT_HEADERS32 pNtHeader32;
	PIMAGE_NT_HEADERS64 pHeaders64;
	PIMAGE_IMPORT_DESCRIPTOR pIatDes;
	BOOL b64 = FALSE;
	NTSTATUS ns = STATUS_NOT_FOUND;
	if (pDosHeader->e_magic!=IMAGE_DOS_SIGNATURE)
	{
		return STATUS_INVALID_IMAGE_FORMAT;
	}
	pNtHeader32 = (PIMAGE_NT_HEADERS32)((PUCHAR)Base + ((PIMAGE_DOS_HEADER)Base)->e_lfanew);
	if (pNtHeader32->Signature!=IMAGE_NT_SIGNATURE)
	{
		return STATUS_INVALID_IMAGE_FORMAT;
	}
	if (pNtHeader32->FileHeader.Machine==IMAGE_FILE_MACHINE_AMD64)
	{
		b64 = TRUE;
		pHeaders64 = (PIMAGE_NT_HEADERS64)((PUCHAR)Base + ((PIMAGE_DOS_HEADER)Base)->e_lfanew);
		pIatDes = (PIMAGE_IMPORT_DESCRIPTOR)((PUCHAR)Base + pHeaders64->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
	}
	else if(pNtHeader32->FileHeader.Machine==IMAGE_FILE_MACHINE_I386)
	{
		pIatDes = (PIMAGE_IMPORT_DESCRIPTOR)((PUCHAR)Base + pNtHeader32->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
	}
	else
	{
		return STATUS_INVALID_IMAGE_FORMAT;
	}
	//////////////////////////////////////////////////////////////////////////
	//�������鷳�����￪ʼ��
	//////////////////////////////////////////////////////////////////////////
	for (; pIatDes->Name; pIatDes++)
	{
		if (_stricmp(szDllName, (PCSTR) ((PUCHAR)Base + pIatDes->Name)) == 0)
		{
			if (b64)
			{
				PIMAGE_THUNK_DATA64 pThunk64;
				for(pThunk64 = (PIMAGE_THUNK_DATA64)((PUCHAR)Base+pIatDes->FirstThunk);pThunk64->u1.Function;pThunk64++)
				{
					if ((ULONG_PTR)pThunk64->u1.Function==ulOrigFunctionAddress)
					{
						WPOFF();
						pThunk64->u1.Function = ulNewFunctionAddress;
						WPON();
						ns = STATUS_SUCCESS;
					}
				}
			}
			else
			{
				PIMAGE_THUNK_DATA32 pThunk32;
				for(pThunk32 = (PIMAGE_THUNK_DATA32)((PUCHAR)Base+pIatDes->FirstThunk);pThunk32->u1.Function;pThunk32++)
				{
					if ((ULONG_PTR)pThunk32->u1.Function==ulOrigFunctionAddress)
					{
						WPOFF();
						pThunk32->u1.Function = ulNewFunctionAddress;
						WPON();
						ns = STATUS_SUCCESS;
					}
				}
			}
			break;
		}
	}
}